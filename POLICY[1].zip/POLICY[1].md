﻿**Politique de Confidentialité**

**Dernière mise à jour** : 03/05/2024

1. Introduction

Bienvenue dans l'application **AGRI BIBLIO**. Nous respectons votre vie privée et nous nous engageons à la protéger. Cette politique de confidentialité explique comment nous traitons les informations des utilisateurs de l'application.

2. Données Personnelles

**AGRI BIBLIO** ne collecte ni ne traite aucune donnée personnelle. Nous ne demandons pas, ne stockons pas et ne partageons pas d'informations personnelles des utilisateurs.

3. Données de l'Application

Nous ne collectons aucune donnée via l'application. Aucune information n'est enregistrée ou transmise à des tiers.

4. Sécurité

La sécurité de vos informations est importante pour nous. Comme **AGRI BIBLIO** ne collecte aucune donnée, il n'y a aucun risque de fuite ou de mauvaise utilisation de vos informations personnelles.

5. Changements de Notre Politique de Confidentialité

Nous pouvons mettre à jour notre politique de confidentialité de temps à autre. Nous vous informerons de tout changement en publiant la nouvelle politique de confidentialité sur cette page.

6. Contactez-Nous

Si vous avez des questions sur cette politique de confidentialité, veuillez nous contacter via l’adresse suivante **tchokolo2clauvel@gmail.com**
